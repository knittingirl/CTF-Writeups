
#!/bin/bash
docker build --tag=robo_quest .
docker run -p 1337:1337 --restart=on-failure --name=robo_quest --detach robo_quest