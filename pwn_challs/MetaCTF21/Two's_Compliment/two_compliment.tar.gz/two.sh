#!/bin/bash

cd /two && ./two
